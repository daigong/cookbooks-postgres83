/* config.h.  Generated from config.h.in by configure.  */
#define HAVE_ICONV_H 1
/* #undef USE_GEOS */
/* #undef USE_JTS */
