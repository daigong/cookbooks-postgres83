Pre-Alpha support for PLJava.

!!! This code will not work against any released pljava version. See pljava developer list
archive for discussion of the changes needed in pljava for this code to work. Let's hope all
the fixes get into the next pljava release.

Put pljava.jar and jts-1.7.1.jar into lib/ directory, then run ant.
